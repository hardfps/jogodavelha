# Velha// duelo — jogo da velha 1v1 online

Site 100% estático (HTML/CSS/JS puro, sem build). O sync entre os dois jogadores
é feito via **Firebase Realtime Database** — por isso precisa configurar um
projeto Firebase grátis antes de subir na Vercel.

## 1. Criar o Firebase (5 min, grátis)

1. Acesse https://console.firebase.google.com e crie um projeto novo.
2. No menu lateral, vá em **Build > Realtime Database** e clique em **Criar banco de dados**.
   - Escolha qualquer região.
   - Selecione **modo de teste** (test mode) — libera leitura/escrita por 30 dias, suficiente pra rodar isso.
3. No menu lateral, vá em **Configurações do projeto** (ícone de engrenagem) > **Geral**.
4. Em "Seus apps", clique no ícone `</>` (Web) e registre um app (não precisa marcar Hosting).
5. Copie o objeto `firebaseConfig` que aparece.
6. Cole os valores em `firebase-config.js`, substituindo os `"COLE_AQUI"`.

### Regras do banco (recomendado antes de expor publicamente)

Test mode expira em 30 dias e é público pra qualquer um. Se quiser deixar mais seguro,
troque as regras em **Realtime Database > Regras** para algo como:

```json
{
  "rules": {
    "rooms": {
      "$room": {
        ".read": true,
        ".write": true,
        ".validate": "newData.hasChildren(['board','turn'])"
      }
    }
  }
}
```

Isso ainda é aberto (não tem autenticação de usuário), mas é o suficiente pra um
joguinho casual entre amigos. Pra produção de verdade valeria adicionar Firebase Auth.

## 2. Rodar local (opcional, pra testar antes)

Não precisa de servidor — só abrir o `index.html` num navegador já funciona,
já que tudo é client-side. Se preferir servir localmente:

```bash
npx serve .
```

## 3. Deploy na Vercel

**Opção A — CLI:**
```bash
npm i -g vercel
cd jogo-da-velha-online
vercel --prod
```

**Opção B — GitHub:**
1. Suba essa pasta pra um repositório no GitHub.
2. Em https://vercel.com/new, importe o repositório.
3. Framework Preset: **Other**. Não precisa configurar build command nem output dir
   (é só HTML estático na raiz).
4. Deploy.

## Como jogar

1. Um jogador clica em **criar sala** → vira o X → recebe um código de 4 caracteres.
2. Manda o código pro outro jogador (WhatsApp, Discord, etc).
3. O outro jogador clica em **entrar em sala**, cola o código → vira o O.
4. Jogam em tempo real. Dá pra clicar em **jogar de novo** ao final pra revanche
   (os dois precisam clicar pra resetar o tabuleiro).

## Limitações conhecidas

- Sem autenticação — quem tiver o código entra na sala.
- Salas antigas não são limpas automaticamente do banco (não é problema em uso
  casual, mas se quiser, dá pra rodar uma Cloud Function pra apagar salas
  antigas, ou apagar manualmente pelo console do Firebase).
- Sem reconexão inteligente se cair a internet no meio da partida — só recarregar
  a página e entrar de novo na mesma sala com o mesmo código funciona, mas o app
  não guarda automaticamente "qual sala eu tava" no reload.
